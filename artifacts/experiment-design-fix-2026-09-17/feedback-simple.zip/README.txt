PhysioFlow Graph session

Events are ordered by sequence; node_id joins records to protocol_snapshot.json.
responses.csv contains one row per submitted value. reaction_time_ms is the captured response time (blank for omissions or multi-response tasks); node_duration_ms includes feedback/confirmation.
Use the complete export for device samples, raw events, runtime state and BIDS files.
